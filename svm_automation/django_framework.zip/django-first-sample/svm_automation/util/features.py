from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import  time

from util.login import login1
from util.conf import selenium_webdriver
from util.conf import element_value_features
from selenium_elements.selenum_fetchelement import Element


class feature_click:
        new_driver = selenium_webdriver.driver
        time.sleep(10)
        Element.fetchelement(new_driver, element_value_features.ctrlDashboard).click()


class feature_vulnerabilityclick:
    new_driver = selenium_webdriver.driver
    time.sleep(10)
    Element.fetchelementbypartiallinktext(new_driver, element_value_features.ctrlvulnerability).click()










