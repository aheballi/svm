from selenium import webdriver
from selenium.webdriver.common.keys import Keys

class credentials:
         url = "https://uat.app.flexerasoftware.com/login/"
         user_name = "aheballi"
         password = "Flexera1!"


class selenium_webdriver:
    driver = webdriver.Firefox(executable_path=r'/home/anusha/SVM/geckodriver/geckodriver')

class element_value_login:
    ctrlLogin = "inputEmail"
    ctrlPassword = "inputPassword"
    btnSubmit = "submit-btn"


class element_value_features:
    ctrlDashboard = "link_notifications"
    ctrlvulnerability = "Vulnerability Manager"




