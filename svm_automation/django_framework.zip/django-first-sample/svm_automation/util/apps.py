from django.apps import AppConfig


class utilConfig(AppConfig):
    name = 'util'
