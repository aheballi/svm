from django.apps import AppConfig


class SeleniumElementsConfig(AppConfig):
    name = 'selenium_elements'
